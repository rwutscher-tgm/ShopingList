import setuptools 
setuptools.setup()